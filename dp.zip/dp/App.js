import React, { Component } from 'react';
import { View, Text, Image, ScrollView, StyleSheet } from 'react-native';

// Code example by Dr. Fuentes; May 21, 2023

export default class App extends Component {
  render() {
    return (
      <ScrollView>
        <View style={styles.container}>
          <Image
            source={{ uri: 'https://scontent.fmnl13-3.fna.fbcdn.net/v/t39.30808-1/434822723_2885463904926984_7696895240887235284_n.jpg?stp=dst-jpg_s200x200&_nc_cat=101&ccb=1-7&_nc_sid=0ecb9b&_nc_eui2=AeFGFhmsxxuFNlu8Q_7K3J1ckUFstEfq0lKRQWy0R-rSUvD1OV8BIwGqLGzc7pQPdI6csHqKbS2GkabhuW34ZWX2&_nc_ohc=rBIHcZYq60gQ7kNvgHrRqdq&_nc_ht=scontent.fmnl13-3.fna&_nc_gid=A--ZvUuocKcR0eNZ96AZ9mE&oh=00_AYA7F9I4tXIMkp6eWZavgWiQ24lNG2enilE8BTyZDPYCWA&oe=66E6A6F2' }}
            style={styles.image}
          />
          <Text style={styles.text}>HOUEN MATTHEW D. VALDOPEÑAS</Text>
            <Text style={styles.text}>20 </Text>
              <Text style={styles.text}>3RD YEAR</Text>
        </View>

        <View style={styles.container}>
          <Image
            source={{ uri: 'https://scontent.fmnl13-3.fna.fbcdn.net/v/t39.30808-1/434822723_2885463904926984_7696895240887235284_n.jpg?stp=dst-jpg_s200x200&_nc_cat=101&ccb=1-7&_nc_sid=0ecb9b&_nc_eui2=AeFGFhmsxxuFNlu8Q_7K3J1ckUFstEfq0lKRQWy0R-rSUvD1OV8BIwGqLGzc7pQPdI6csHqKbS2GkabhuW34ZWX2&_nc_ohc=rBIHcZYq60gQ7kNvgHrRqdq&_nc_ht=scontent.fmnl13-3.fna&_nc_gid=A--ZvUuocKcR0eNZ96AZ9mE&oh=00_AYA7F9I4tXIMkp6eWZavgWiQ24lNG2enilE8BTyZDPYCWA&oe=66E6A6F2' }} // Replace with your own image URL
            style={styles.image}
          />
          <Text style={styles.text}></Text>
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 20,
  },
  image: {
    width: 200,
    height: 200,
  },
  text: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 10,
  },
});